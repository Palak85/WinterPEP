#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }

    if(root->data>data){
        insert(root->left,data);
    }
    else{
        insert(root->right,data);
    }
}

void printRange(Node* root,int low,int high){
    if(root==NULL){
        return;
    }

    if(root->data>low){
        printRange(root->left,low,high);
    }

    if(root->data>low && root->data<high){
        cout<<root->data<<" ";
    }

    if(root->data<high){
        printRange(root->right,low,high);
    }

}

void inorder(Node* root){
    if(root==NULL){
        return;
    }

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
int main(){
    Node* root=NULL;

    insert(root,40);
    insert(root,20);
    insert(root,50);
    insert(root,10);
    insert(root,30);
    insert(root,45);
    insert(root,60);

    inorder(root);
    cout<<endl;

    int low=20;
    int high=50;
    printRange(root,low,high);
}
