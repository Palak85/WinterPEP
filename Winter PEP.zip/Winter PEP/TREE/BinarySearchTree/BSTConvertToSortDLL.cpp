#include<iostream>
using namespace std;

class Node{
public:
    int data;
    Node* left;
    Node* right;
    Node* next;
    Node* Prev; 

    Node(int x){
        data = x;
        left = right = nullptr;
        next = Prev = nullptr;
    }
};

void insert(Node*& root, int x){
    if(root == nullptr){
        root = new Node(x);
        return;
    }
    if(x < root->data)
        insert(root->left, x);
    else
        insert(root->right, x);
}

void bstToDLL(Node* root, Node*& head, Node*& lastVisited){
    if(root == nullptr)
        return;

    bstToDLL(root->left, head, lastVisited);

    if(lastVisited == nullptr){
        head = root;                   
    } else {
        lastVisited->next = root;      
        root->Prev = lastVisited;   
    }

    lastVisited = root;      

    bstToDLL(root->right, head, lastVisited);
}

void printDLL(Node* head){
    cout << "Doubly Linked List: ";
    while(head){
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

void inorder(Node* root){
    if(root == nullptr) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main(){
    Node* root = nullptr;
    int n, x;

    cout << "Enter number of nodes: ";
    cin >> n;

    for(int i = 0; i < n; i++){
        cin >> x;
        insert(root, x);
    }

    cout << "Inorder (BST): ";
    inorder(root);
    cout << endl;

    Node* head = nullptr;
    Node* lastVisited = nullptr;

    bstToDLL(root, head, lastVisited);

    printDLL(head);

    return 0;
}