#include<iostream>
using namespace std;

class Node{
public:
    int data;
    Node* left;
    Node* right;
    Node* next;

    Node(int x){
        data = x;
        left = right = next = nullptr;
    }
};

void insert(Node*& root, int x){
    if(root == nullptr){
        root = new Node(x);
        return;
    }
    if(x < root->data)
        insert(root->left, x);
    else
        insert(root->right, x);
}

void bstToSLL(Node* root, Node*& head, Node*& prev){
    if(root == nullptr)
        return;

    bstToSLL(root->left, head, prev);

    if(prev == nullptr)
        head = root;
    else
        prev->next = root;

    prev = root;

    bstToSLL(root->right, head, prev);

    root->left = nullptr;
    root->right = nullptr;
}

void printSLL(Node* head){
    cout << "Singly Linked List: ";
    while(head){
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

void inorder(Node* root){
    if(root == nullptr) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main(){
    Node* root = nullptr;
    int n, x;

    cin >> n;

    for(int i = 0; i < n; i++){
        cin >> x;
        insert(root, x);
    }

    inorder(root);
    cout << endl;

    Node* head = nullptr;
    Node* prev = nullptr;

    bstToSLL(root, head, prev);

    printSLL(head);

    return 0;
}