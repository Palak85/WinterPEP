#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int x){
        data = x;
        left = right = NULL;
        height = 1;
    }
};

int height(Node* root){
    if(root == NULL)
        return 0;
    return root->height;
}

int getBalance(Node* root){
    if(root == NULL)
        return 0;
    return height(root->left) - height(root->right);
}

Node* rightRotate(Node* y){
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

Node* leftRotate(Node* x){
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

Node* insertAVL(Node* root, int key){
    if(root == NULL)
        return new Node(key);

    if(key < root->data)
        root->left = insertAVL(root->left, key);
    else if(key > root->data)
        root->right = insertAVL(root->right, key);
    else
        return root;

    root->height = 1 + max(height(root->left), height(root->right));

    int balance = getBalance(root);

    if(balance > 1 && key < root->left->data)
        return rightRotate(root);

    if(balance < -1 && key > root->right->data)
        return leftRotate(root);

    if(balance > 1 && key > root->left->data){
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if(balance < -1 && key < root->right->data){
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

bool isBalanced(Node* root){
    if(root == NULL)
        return true;

    int lh = height(root->left);
    int rh = height(root->right);

    if(abs(lh - rh) > 1)
        return false;

    return isBalanced(root->left) && isBalanced(root->right);
}

void inorder(Node* root){
    if(root == NULL)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main(){
    Node* root = NULL;
    int n, x;

    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> x;
        root = insertAVL(root, x);
    }

    inorder(root);
    cout << endl;

    if(isBalanced(root))
        cout << "AVL TREE IS BALANCED";
    else
        cout << "AVL TREE IS NOT BALANCED";

    cout<<endl;
    cout<<"Root is: "<<root->data;
    
    return 0;
}