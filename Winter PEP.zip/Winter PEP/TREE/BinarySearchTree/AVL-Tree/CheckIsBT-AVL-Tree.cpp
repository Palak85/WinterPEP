#include <iostream>
#include <queue>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};


void insert(Node*& root, int key) {
    if (root == NULL) {
        root = new Node(key);
        return;
    }

    queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        Node* temp = q.front();
        q.pop();

        if (temp->left == NULL) {
            temp->left = new Node(key);
            return;
        } else
            q.push(temp->left);

        if (temp->right == NULL) {
            temp->right = new Node(key);
            return;
        } else
            q.push(temp->right);
    }
}

void inorder(Node* root) {
    if (root == NULL)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

bool checkst(Node* &root,int &head)
{
    if(root==nullptr)
        return true;
    
    bool p=checkst(root->left,head);
    
    if(p==false)
        return false;
        
    if(root->data < head)
        return false;
        
    head=root->data;
    
    bool b=checkst(root->right,head);
    if(b==false)
        return false;
    
        
    return true;
    
}


int height(Node* root){
    if(root == NULL)
        return 0;

    int lh = height(root->left);
    int rh = height(root->right);

    return max(lh, rh) + 1;
}

bool isBalanced(Node* root){
    if(root == NULL)
        return true;

    int lh = height(root->left);
    int rh = height(root->right);

    int balanceFactor = lh - rh;

    if(balanceFactor < -1 || balanceFactor > 1)
        return false;

    return isBalanced(root->left) && isBalanced(root->right);
}


int main() {
    Node* root = NULL;

    insert(root, 50);
    insert(root, 30);
    insert(root, 60);
    insert(root, 10);
    insert(root, 40);


    inorder(root);
    cout<<endl;
    
    int head=0;
    if(checkst(root,head))
        cout<<"BT is BST";
    else
        cout<<"BT is not BST";

        cout<<endl;

    if(isBalanced(root))
        cout << "Tree is BALANCED"<<endl;
    else
        cout << "Tree is NOT BALANCED"<<endl;


    if(isBalanced && checkst){
        cout<<"BT is AVL tree";
    }
    else{
        cout<<"IT is not AVL tree";
    }
 
    return 0;
}