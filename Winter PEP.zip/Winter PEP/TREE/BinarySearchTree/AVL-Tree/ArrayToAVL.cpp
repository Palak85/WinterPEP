#include<iostream>
#include<algorithm>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int x){
        data = x;
        left = right = NULL;
        height = 1;
    }
};

int height(Node* root){
    if(root == NULL)
        return 0;
    return root->height;
}

Node* buildAVL(int arr[], int start, int end){
    if(start > end)
        return NULL;

    int mid = (start + end) / 2;

    Node* root = new Node(arr[mid]);

    root->left = buildAVL(arr, start, mid - 1);
    root->right = buildAVL(arr, mid + 1, end);

    root->height = 1 + max(height(root->left), height(root->right));

    return root;
}

void inorder(Node* root){
    if(root == NULL)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

bool isBalanced(Node* root){
    if(root == NULL)
        return true;

    int lh = height(root->left);
    int rh = height(root->right);

    if(abs(lh - rh) > 1)
        return false;

    return isBalanced(root->left) && isBalanced(root->right);
}

int main(){

    int n;
    cin >> n;

    int arr[n];

    for(int i = 0; i < n; i++)
        cin >> arr[i];

    sort(arr, arr + n);

    Node* root = buildAVL(arr, 0, n-1);

    cout << "Inorder Traversal: ";
    inorder(root);
    cout << endl;

    if(isBalanced(root))
        cout << "AVL TREE IS BALANCED";
    else
        cout << "AVL TREE IS NOT BALANCED";

    return 0;
}