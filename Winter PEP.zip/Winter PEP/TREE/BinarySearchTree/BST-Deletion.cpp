#include<iostream>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }
    if(data < root->data)
        insert(root->left,data);
    else
        insert(root->right,data);
}

Node* delet(Node* root, int key){
    if(root==NULL)
        return root;

    if(key < root->data)
        root->left = delet(root->left, key);
    else if(key > root->data)
        root->right = delet(root->right, key);
    else{
        if(root->left==NULL)
            return root->right;
        else if(root->right==NULL)
            return root->left;

        Node* temp = root->right;
        while(temp->left!=NULL)
            temp = temp->left;

        root->data = temp->data;
        root->right = delet(root->right, temp->data);
    }
    return root;
}

void inorder(Node* root){
    if(root==NULL)
        return;
    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}

int main(){
    Node* root=NULL;

    insert(root,50);
    insert(root,20);
    insert(root,30);
    insert(root,90);
    insert(root,25);
    insert(root,40);

    cout<<"Before Deletion: ";
    inorder(root);

    root = delet(root, 30);   

    cout<<"\nAfter Deletion: ";
    inorder(root);
}