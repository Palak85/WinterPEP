#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }

    if(root->data>data){
        insert(root->left,data);
    }
    else{
        insert(root->right,data);
    }
}

void findAncestors(Node* root, int key){
    if(root == NULL){
        return;
    }

    if(root->data == key){
        return;
    }

    if(key < root->data){
        cout << root->data << " ";
        findAncestors(root->left, key);
    }
    else{
        cout << root->data << " ";
        findAncestors(root->right, key);
    }
}

void inorder(Node* root){
    if(root==NULL){
        return;
    }

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
int main(){
    Node* root=NULL;

    insert(root,50);
    insert(root,20);
    insert(root,90);
    insert(root,10);
    insert(root,25);

    inorder(root);
    cout<<endl;

    int key=15;
    findAncestors(root,key);
}