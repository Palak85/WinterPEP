#include<iostream>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x){
        data = x;
        left = NULL;
        right = NULL;
    }
};

void insert(Node* &root, int data){
    if(root == NULL){
        root = new Node(data);
        return;
    }

    if(data < root->data)
        insert(root->left, data);
    else
        insert(root->right, data);
}

void inorder(Node* root){
    if(root == NULL)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

bool searchBST(Node* root, int key){
    if(root == NULL)
        return false;

    if(root->data == key)
        return true;

    if(key < root->data)
        return searchBST(root->left, key);
    else
        return searchBST(root->right, key);
}

int main(){
    Node* root = NULL;

    insert(root, 50);
    insert(root, 20);
    insert(root, 30);
    insert(root, 90);
    insert(root, 25);
    insert(root, 40);

    cout << "Inorder traversal: ";
    inorder(root);
    cout << endl;

    int key = 40;

    if(searchBST(root, key))
        cout << "Key found";
    else
        cout << "Key not found";

    return 0;
}