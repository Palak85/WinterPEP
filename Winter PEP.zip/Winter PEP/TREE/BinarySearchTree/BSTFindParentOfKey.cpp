#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }

    if(root->data>data){
        insert(root->left,data);
    }
    else{
        insert(root->right,data);
    }
}

// void findparent(Node* root,int key){
//     if(root==NULL){
//         return;
//     }
//     if((root->left != NULL && root->left->data == key) || (root->right != NULL && root->right->data == key)){
//         cout<<root->data;
//     }

//     findparent(root->left,key);
//     findparent(root->right,key);
// }

void findParent(Node* root, int key){
    if(root == NULL || root->data == key){
        cout << "No parent";
        return;
    }

    if((root->left && root->left->data == key) ||
       (root->right && root->right->data == key)){
        cout << root->data;
        return;
    }

    if(key < root->data){
        findParent(root->left, key);
    }
    else{
        findParent(root->right, key);
    }
}

void inorder(Node* root){
    if(root==NULL){
        return;
    }

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
int main(){
    Node* root=NULL;

    insert(root,50);
    insert(root,20);
    insert(root,30);
    insert(root,90);
    insert(root,25);
    insert(root,40);

    inorder(root);
    cout<<endl;
    
    int key=25;
    findParent(root,key);
}