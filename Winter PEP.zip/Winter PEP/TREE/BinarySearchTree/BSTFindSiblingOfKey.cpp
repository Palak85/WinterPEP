#include<iostream>
#include<queue>
using namespace std;
struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }

    if(root->data>data){
        insert(root->left,data);
    }
    else{
        insert(root->right,data);
    }
}

void siblingOfKey(Node* root, int key){
    if(root==NULL){
        return;
    }

    if(root->left && root->left->data==key){
        if(root->right){
             cout<<root->right->data<<endl;
        }
        else{
            cout<<"There is no sibling."<<endl;
        }
        return;
    }

    if(root->right &&root->right->data==key){
        if(root->left){
            cout<<root->left->data<<endl;
        }
        else{
            cout<<"There is no sibling."<<endl;
        }
        return;
    }

    if(key<root->data){
        siblingOfKey(root->left,key);
    }
    else{
        siblingOfKey(root->right,key);
    }

}

void inorder(Node* root){
    if(root==NULL){
        return;
    }

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}

void levelOrder(Node* root){
    if(root==NULL){
        return;
    }
    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        cout<<temp->data<<" ";

        if(temp->left){
            q.push(temp->left);
        }

        if(temp->right){
            q.push(temp->right);
        }
    }
}
int main(){
    Node* root=NULL;

    insert(root,50);
    insert(root,20);
    insert(root,30);
    insert(root,90);
    insert(root,25);
    insert(root,40);

    cout<<"Inorder: ";
    inorder(root);
    cout<<endl;

    cout<<"Level-Order: ";
    levelOrder(root);
    cout<<endl;

    cout<<"Sibling of 40: ";
    int k=40;
    siblingOfKey(root, k);
}