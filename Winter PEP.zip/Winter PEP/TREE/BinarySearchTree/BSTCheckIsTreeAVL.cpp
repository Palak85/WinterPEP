#include<iostream>
#include<cmath>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x){
        data = x;
        left = NULL;
        right = NULL;
    }
};

void insert(Node*& root, int data){
    if(root == NULL){
        root = new Node(data);
        return;
    }

    if(data < root->data)
        insert(root->left, data);
    else
        insert(root->right, data);
}

int height(Node* root){
    if(root == NULL)
        return 0;

    int lh = height(root->left);
    int rh = height(root->right);

    return max(lh, rh) + 1;
}

bool isBalanced(Node* root){
    if(root == NULL)
        return true;

    int lh = height(root->left);
    int rh = height(root->right);

    int balanceFactor = lh - rh;

    if(balanceFactor < -1 || balanceFactor > 1)
        return false;

    return isBalanced(root->left) && isBalanced(root->right);
}

void inorder(Node* root){
    if(root == NULL)
        return;

    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main(){
    Node* root = NULL;

    insert(root, 50);
    insert(root, 30);
    insert(root, 40);
    insert(root, 80);
    insert(root, 100);
    insert(root, 60);

    cout << "Inorder traversal: ";
    inorder(root);
    cout << endl;

    if(isBalanced(root))
        cout << "Tree is BALANCED";
    else
        cout << "Tree is NOT BALANCED";
 
    return 0;
}