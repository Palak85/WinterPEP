#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* left;
    Node* right;
    Node(int x){
        data=x;
        left=NULL;
        right=NULL;
    }
};

void insert(Node* &root,int data){
    if(root==NULL){
        root=new Node(data);
        return;
    }

    if(root->data>data){
        insert(root->left,data);
    }
    else{
        insert(root->right,data);
    }
}

void findMin(Node* root){
    if(root==NULL){
        return;
    }
    while(root->left!=NULL){
        root=root->left;
    }
    cout<<root->data;
    cout<<endl;
}

void findMax(Node* root){
        if(root==NULL){
        return;
    }
    while(root->right!=NULL){
        root=root->right;
    }
    cout<<root->data;
}

void inorder(Node* root){
    if(root==NULL){
        return;
    }

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}
int main(){
    Node* root=NULL;

    insert(root,50);
    insert(root,20);
    insert(root,30);
    insert(root,90);
    insert(root,25);
    insert(root,40);

    inorder(root);
    cout<<endl;

    findMin(root);

    findMax(root);
}