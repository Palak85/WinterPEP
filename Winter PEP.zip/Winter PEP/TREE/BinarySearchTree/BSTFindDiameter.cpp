#include<iostream>
#include<algorithm>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int x){
        data = x;
        left = right = NULL;
        height = 1;
    }
};

int height(Node* root){
    if(root == NULL)
        return 0;
    return root->height;
}

int getBalance(Node* root){
    if(root == NULL)
        return 0;
    return height(root->left) - height(root->right);
}

Node* rightRotate(Node* y){
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = 1 + max(height(y->left), height(y->right));
    x->height = 1 + max(height(x->left), height(x->right));

    return x;
}

Node* leftRotate(Node* x){
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = 1 + max(height(x->left), height(x->right));
    y->height = 1 + max(height(y->left), height(y->right));

    return y;
}

Node* insertAVL(Node* root, int key){

    if(root == NULL)
        return new Node(key);

    if(key < root->data)
        root->left = insertAVL(root->left, key);
    else if(key > root->data)
        root->right = insertAVL(root->right, key);
    else
        return root;

    root->height = 1 + max(height(root->left), height(root->right));

    int balance = getBalance(root);

    if(balance > 1 && key < root->left->data)
        return rightRotate(root);

    if(balance < -1 && key > root->right->data)
        return leftRotate(root);

    if(balance > 1 && key > root->left->data){
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if(balance < -1 && key < root->right->data){
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

int diameterUtil(Node* root, int &diameter){
    if(root == NULL)
        return 0;

    int leftHeight = diameterUtil(root->left, diameter);
    int rightHeight = diameterUtil(root->right, diameter);

    diameter = max(diameter, leftHeight + rightHeight);

    return 1 + max(leftHeight, rightHeight);
}

int diameter(Node* root){
    int dia = 0;
    diameterUtil(root, dia);
    return dia;
}

int main(){

    Node* root = NULL;

    root = insertAVL(root, 10);
    root = insertAVL(root, 20);
    root = insertAVL(root, 30);
    root = insertAVL(root, 40);
    root = insertAVL(root, 50);
    root = insertAVL(root, 25);

    cout<<"Diameter of AVL tree (edges): "<<diameter(root);

    return 0;
}