            return;
        }
        else{
            q.push(temp->right);
        }
    }
}

void LevelOrder(Node* root){
    if(root==NULL){
        return ;
    }