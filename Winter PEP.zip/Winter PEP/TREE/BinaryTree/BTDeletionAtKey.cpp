#include<iostream>
#include<queue>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x ){
        data=x;
        left = right =NULL;
    }
};

void insert(Node* &root,int x){
    if(root==NULL){
        Node* newnode = new Node(x);
        root=newnode;
        return;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        if(temp->left==NULL){
            temp->left=new Node(x);
            return;
        }
        else{
            q.push(temp->left);
        }

        if(temp->right==NULL){
            temp->right=new Node(x);
            return;
        }
        else{
            q.push(temp->right);
        }
    }
}

void deleteLastNode(Node* &root,Node* delNode){
    if(root == NULL)
    return;

    if(root == delNode){
    delete root;
    root = NULL;
    return;
}
    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        if(temp->left!=NULL){
            if(temp->left==delNode){
                delete temp->left;
                temp->left=NULL;
                return;
            }
            else{
                q.push(temp->left);
            }
        }

        if(temp->right!=NULL){
            if(temp->right==delNode){
                delete temp->right;
                temp->right=NULL;
                return;
            }
            else{
                q.push(temp->right);
            }
        }
    }
}


void deleteAtKeynode(Node* &root, int key){
    if(root==NULL){
        return;
    }

    if(root->left==NULL && root->right==NULL){
        if(root->data==key){
            delete root;
            root=NULL;
        }
        return;
    }

    Node* temp;
    Node* keyNode=NULL;

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        temp=q.front();
        q.pop();

        if(temp->data==key){
            keyNode=temp;
        }

        if(temp->left){
            q.push(temp->left);
        }

        if(temp->right){
            q.push(temp->right);
        }
    }
    if(keyNode!=NULL){
            keyNode->data=temp->data;
            deleteLastNode(root,temp);
        }
}

void LevelOrder(Node* &root){
    if(root==NULL){
        return ;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        cout<<temp->data<<" ";

        if(temp->left != NULL){
            q.push(temp->left);
        }

        if(temp->right != NULL){
            q.push(temp->right);
        }
    }
}

int main(){
    Node* root=NULL;
    int key=40;

    insert(root,10);
    insert(root,20);
    insert(root,30);
    insert(root,40);
    insert(root,50);
    insert(root,60);
    insert(root,70);
    insert(root,80);

    cout<<"Level order traversal: ";
    LevelOrder(root);
    cout<<endl;

    deleteAtKeynode(root,key);

    cout<<"After deletion at keynode: ";
    LevelOrder(root);
    cout<<endl;
    return 0;
}