#include<iostream>
#include<queue>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x ){
        data=x;
        left = right =NULL;
    }
};

void insert(Node* &root,int x){
    if(root==NULL){
        Node* newnode = new Node(x);
        root=newnode;
        return;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        if(temp->left==NULL){
            temp->left=new Node(x);
            return;
        }
        else{
            q.push(temp->left);
        }

        if(temp->right==NULL){
            temp->right=new Node(x);
            return;
        }
        else{
            q.push(temp->right);
        }
    }
}

void deleteLastNode(Node* root){
    if(root==NULL)
        return;

    if(root->left==NULL && root->right==NULL){
        delete(root);
        root=NULL;
        return;
    }

    queue<Node*> q;
    q.push(root);

    Node* temp;
    Node* parent=NULL;

    while(!q.empty()){
        temp=q.front();
        q.pop();

        if(temp->left!=NULL){
            parent=temp;
            q.push(temp->left);
        }

        if(temp->right!=NULL){
            parent=temp;
            q.push(temp->right);
        }
    }

    if(parent->right==temp){
        delete parent->right;
        parent->right=NULL;
    }
    else{
        delete parent->left;
        parent->left=NULL;
    }
}

void LevelOrder(Node* root){
    if(root==NULL){
        return ;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        cout<<temp->data<<" ";

        if(temp->left != NULL){
            q.push(temp->left);
        }

        if(temp->right != NULL){
            q.push(temp->right);
        }
    }
}

int main(){
    Node* root=NULL;

    insert(root,10);
    insert(root,20);
    insert(root,30);
    insert(root,40);
    insert(root,50);
    insert(root,60);
    insert(root,70);
    insert(root,80);

    cout<<"Level order traversal: ";
    LevelOrder(root);
    cout<<endl;

    deleteLastNode(root);

    cout<<"After last node deletion: ";
    LevelOrder(root);
    cout<<endl;

    return 0;
}