#include<iostream>
#include<queue>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x ){
        data=x;
        left = right =NULL;
    }
};

void insert(Node* &root,int x){
    if(root==NULL){
        Node* newnode = new Node(x);
        root=newnode;
        return;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        if(temp->left==NULL){
            temp->left=new Node(x);
            return;
        }
        else{
            q.push(temp->left);
        }

        if(temp->right==NULL){
            temp->right=new Node(x);
            return;
        }
        else{
            q.push(temp->right);
        }
    }
}


void inorder(Node* root){
    if(root==NULL)
        return;

    inorder(root->left);
    cout<<root->data<<" ";
    inorder(root->right);
}


void inorderSearch(Node* root,int key){
    if(root==NULL){
        return ;
    }
    
    inorderSearch(root->left,key);

    if(root->data==key){
        cout<<root->data<<endl;
        return ;   
    }

    inorderSearch(root->right,key);

}




int main(){
    Node* root=NULL;

    insert(root,10);
    insert(root,20);
    insert(root,30);
    insert(root,40);
    insert(root,50);
    insert(root,60);
    insert(root,70);
    insert(root,80);

    cout<<"Inorder order traversal: ";
    inorder(root);
    cout<<endl;

    int key=60;
    inorderSearch(root,key);

    return 0;
}