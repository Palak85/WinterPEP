//IT IS FOR LEFT SIDE NODES.........

// #include<iostream>
// #include<queue>
// using namespace std;

// struct Node{
//     int data;
//     Node* left;
//     Node* right;

//     Node(int x ){
//         data=x;
//         left = right =NULL;
//     }
// };

// void insert(Node* &root,int x){
//     if(root==NULL){
//         Node* newnode = new Node(x);
//         root=newnode;
//         return;
//     }

//     queue<Node*> q;
//     q.push(root);

//     while(!q.empty()){
//         Node* temp=q.front();
//         q.pop();

//         if(temp->left==NULL){
//             temp->left=new Node(x);
//             return;
//         }
//         else{
//             q.push(temp->left);
//         }

//         if(temp->right==NULL){
//             temp->right=new Node(x);
//             return;
//         }
//         else{
//             q.push(temp->right);
//         }
//     }
// }

// void LevelOrder(Node* root){
//     if(root==NULL){
//         return ;
//     }

//     queue<Node*> q;
//     q.push(root);

//     while(!q.empty()){
//         Node* temp=q.front();
//         q.pop();

//         cout<<temp->data<<" ";

//         if(temp->left != NULL){
//             q.push(temp->left);
//         }

//         if(temp->right != NULL){
//             q.push(temp->right);
//         }
//     }
// }
// int levelCount(Node* root){
//     if(root==NULL){
//         return 0;
//     }
//     return 1 + max(levelCount(root->left),levelCount(root->right));
// }

// void visitedNode(Node* root, int level,int &visited){
//     if(root==NULL){
//         return;
//     }

//     if(level>visited){
//         cout<<root->data<<" ";
//         visited=level;
//     }

//     visitedNode(root->left,level+1,visited);
//     visitedNode(root->right,level+1,visited);
// }


// int main(){
//     Node* root=NULL;

//     insert(root,10);
//     insert(root,20);
//     insert(root,30);
//     insert(root,40);
//     insert(root,50);
//     insert(root,60);
//     insert(root,70);
//     insert(root,80);


//     cout<<"Level order traversal: ";
//     LevelOrder(root);
//     cout<<endl;

//     int level=levelCount(root);
//     cout<<level<<endl;
//     int visited=0;
//     visitedNode(root, 1,visited);
//     return 0;
// }


//IT IS FOR RIGHT SIDE NODES..........
#include<iostream>
#include<queue>
using namespace std;

struct Node{
    int data;
    Node* left;
    Node* right;

    Node(int x ){
        data=x;
        left = right =NULL;
    }
};

void insert(Node* &root,int x){
    if(root==NULL){
        Node* newnode = new Node(x);
        root=newnode;
        return;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        if(temp->left==NULL){
            temp->left=new Node(x);
            return;
        }
        else{
            q.push(temp->left);
        }

        if(temp->right==NULL){
            temp->right=new Node(x);
            return;
        }
        else{
            q.push(temp->right);
        }
    }
}

void LevelOrder(Node* root){
    if(root==NULL){
        return ;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        Node* temp=q.front();
        q.pop();

        cout<<temp->data<<" ";

        if(temp->left != NULL){
            q.push(temp->left);
        }

        if(temp->right != NULL){
            q.push(temp->right);
        }
    }
}
int levelCount(Node* root){
    if(root==NULL){
        return 0;
    }
    return 1 + max(levelCount(root->left),levelCount(root->right));
}

void visitedNode(Node* root, int level,int &visited){
    if(root==NULL){
        return;
    }

    if(level>visited){
        cout<<root->data<<" ";
        visited=level;
    }
    visitedNode(root->right,level+1,visited);
    visitedNode(root->left,level+1,visited);
}


int main(){
    Node* root=NULL;

    insert(root,10);
    insert(root,20);
    insert(root,30);
    insert(root,40);
    insert(root,50);
    insert(root,60);
    insert(root,70);
    insert(root,80);


    cout<<"Level order traversal: ";
    LevelOrder(root);
    cout<<endl;

    int level=levelCount(root);
    cout<<level<<endl;
    int visited=0;
    visitedNode(root, 1,visited);
    return 0;
}











