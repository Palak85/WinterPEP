#include<iostream>
using namespace std;

void divideandreverse(int arr[], int n, int k){

    if(n % k != 0){
        cout<<"Cannot divide equally";
        return;
    }
    int part = n / k;
    for(int i = 0; i < n; i += part){

        int start = i;
        int end = i + part - 1;

        while(start < end){
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;

            start++;
            end--;
        }
    }

    for(int i = 0; i < n; i++)
        cout<<arr[i]<<" ";
}

int main(){

    int arr[]={1,5,8,10,15,18,21,23,26};
    int n = sizeof(arr)/sizeof(arr[0]);
    int k=3;

    divideandreverse(arr,n,k);
}