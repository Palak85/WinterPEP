//IN THIS CODE WE ARE DIVIDING ARRAY IN 3 PARTS WHOSE SUB ARRAY SUM = TO TOTAL SUM DIVIDE BY 3.........
#include<iostream>
#include<vector>
using namespace std;
bool SlidingW(vector <int> &arr){
    int m=arr.size();
    int sum=0;
    for(int i=0;i<m;i++){
        sum+=arr[i];
    }
    if(m%3!=0){
        cout<<"Array size is not divisible by 3"<<endl;
        return false;
    }
    int target=sum/3;
    if(sum%3!=0){
        cout<<"Target is not comletely divisible"<<endl;
        return false;
    }
    int count=0;
    int totsum=0;
    for(int i=0;i<m;i++){
        totsum+=arr[i];
        if(totsum==target){
            count++;
            totsum=0;
        }
    }
    return count==3;
}
int main(){
    vector<int> arr={3,9,-4,5,2,1,2,2,4};
    if(SlidingW(arr)){
        cout<<"True";
    }
    else{
        cout<<"False";
    }
}