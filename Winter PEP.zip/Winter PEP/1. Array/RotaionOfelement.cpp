#include<iostream>
#include<algorithm>
using namespace std;
int main(){
    int arr[]={1,3,5,2,10,8,7};
    int m= sizeof(arr)/sizeof(arr[0]);
    int n=3;//number of rotaion
    // int temp[3];
    // for(int i=0;i<n;i++){
    //     temp[i]=arr[i];
    // }
    // for(int i=n;i<m;i++){
    //     arr[i-n]=arr[i];
    // }
    // for(int k=0;k<m;k++){
    //     arr[m-n+k]=temp[k];
    // }
    // for (int i = 0; i < m; i++) {
    //     cout << arr[i] << " ";
    // }


    //in this inbuild function used i.e. rotate
    rotate(arr,arr+n,arr+m);
    for (int i = 0; i < m; i++) {
        cout << arr[i] << " ";
    }
}

