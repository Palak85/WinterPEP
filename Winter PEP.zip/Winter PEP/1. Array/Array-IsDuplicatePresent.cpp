#include <iostream>
#include <vector>
using namespace std;


bool checkdupbyk(vector<int> &arr,int k)
{
   int n=arr.size();
   
   for(int i=0;i<n;i++)
   {
       for(int j=1;j<=k && j<n;j++)
       {
           if(arr[i]==arr[i+j])
                return true;
       }
    }
    
    return false;
   
}

int main() {
  vector<int> arr={1,2,4,1,3,1,9};
  int k=4;
  if(checkdupbyk(arr,k))
    cout<<"true";
    else
    cout<<"false";
}