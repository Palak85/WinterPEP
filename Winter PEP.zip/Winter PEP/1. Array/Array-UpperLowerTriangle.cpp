#include <iostream>
#include <vector>
using namespace std;

bool uppertriangle(vector<vector<int>> &mat)
{
    int r=mat.size();
    int c=mat[0].size();
    for(int i=1;i<=r-1;i++)
    {
        for(int j=0;j<=i-1;j++)
            {
                if(mat[i][j]!=0)
                return false;
            }
    }
    return true;
}

bool lowertriangle(vector<vector<int>> &mat)
{
    int r=mat.size();
    int c=mat[0].size();
    for(int i=0;i<r-1;i++)
    {
        for(int j=c-1;j>i;j--)
        {
             if(mat[i][j]!=0)
                return false;
            
        }
    }
    return true;
}

bool triangular(vector<vector<int>> &mat)
{  
    if(uppertriangle(mat)||lowertriangle(mat))
        return true;
    else
        return false;
}


int main() {
 vector<vector<int>> mat={
      {1,2,3},
      {4,5,6},
      {7,8,9}
  };
  
  if(triangular(mat))
    cout<<"true";
    else
    cout<<"false";
}