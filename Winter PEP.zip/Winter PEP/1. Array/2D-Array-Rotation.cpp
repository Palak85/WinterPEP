#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main() {

    vector<vector<int>> mat={
        {3,9,2},
        {6,4,5},
        {1,7,8}
    };

    for(int i=0;i<mat.size();i++){
        sort(mat[i].begin(), mat[i].end());
    }

    for(int i=0;i<mat.size();i++){
        for(int j=0;j<mat[i].size();j++)
            cout<<mat[i][j]<<" ";
        cout<<endl;
    }
}