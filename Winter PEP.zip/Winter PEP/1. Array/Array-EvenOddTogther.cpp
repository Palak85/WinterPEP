#include<iostream>
#include<algorithm>
using namespace std;

void evenodd(int arr[], int n){
    int pos = 0;
    for(int i = 0; i < n; i++){
        if(arr[i] % 2 == 0){
            swap(arr[i], arr[pos]);
            pos++;
        }
    }
    sort(arr, arr + pos);        
    sort(arr + pos, arr + n);    

    for(int i = 0; i < n; i++)
        cout << arr[i] << " ";
}

int main(){
    int arr[5]={1,8,6,7,3};
    int n=5;

    evenodd(arr,n);
}