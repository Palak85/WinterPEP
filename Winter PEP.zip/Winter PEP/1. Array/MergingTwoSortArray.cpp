#include <iostream>
using namespace std;

int main() {
    int a[] = {2,5,8,13};
    int b[] = {1,3,7,9,11};

    int n = 4, m = 5;
    int c[n + m];

    int i = 0, j = 0, k = 0;

    while (i < n && j < m) {
        if (a[i] <= b[j])
            c[k++] = a[i++];
        else
            c[k++] = b[j++];
    }

    while (i < n)
        c[k++] = a[i++];

    while (j < m)
        c[k++] = b[j++];

    for (int x : c)
        cout << x << " ";

    return 0;
}