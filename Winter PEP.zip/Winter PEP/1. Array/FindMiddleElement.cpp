//Finding middle element without using Arithmatic operator

// #include <iostream>
// using namespace std;
// int main() {
//     int n;
//     cin>>n;
//     int a[n];
//     for(int i=0;i<n;i++){
//         cin>>a[i];
//     }
//     int slow = 0;
//     int fast = 0;

//     while (fast<n && fast + 1<n) {
//         slow++;
//         fast += 2;
//     }

//     cout << a[slow];
//     return 0;
// }


#include <iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int arr[n];
    for (int i=0;i<n;i++){
        cin >> arr[i];
    }
    int slow =0;
    int fast = n-1;
    while (slow < fast ){
        slow++;
        fast--;
    }
    if (slow==fast){
        cout << arr[slow];
    }
    else {
        cout << (arr[slow]) << arr[fast];
    }
    return 0;
}