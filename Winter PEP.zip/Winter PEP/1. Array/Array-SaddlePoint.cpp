#include <iostream>
#include <vector>
using namespace std;


void saddlepoint(vector<vector<int>> &mat)
{   
    int r=mat.size();
    int c=mat[0].size();
    vector<int> minmax(r),maxmin(c);
    
    for(int i=0; i<r;i++)
        {   
            minmax[i]=mat[i][0];
            for(int j=0; j<c;j++)
        {
               if(minmax[i]>mat[i][j])
                    minmax[i]=mat[i][j];
        }
        }
        
        int max1=minmax[0];
        for(int k=0;k<r;k++)
        {
               if(max1<minmax[k])
                max1=minmax[k];
        }
       
        for(int j=0; j<c;j++)
        {   
            maxmin[j]=mat[0][j];
            for(int i=0; i<r;i++)
        {
               if(maxmin[j]<mat[i][j])
                    maxmin[j]=mat[i][j];
        }
        }
        
        int min1=maxmin[0];
        for(int k=0;k<r;k++)
        {
               if(min1>maxmin[k])
                min1=maxmin[k];
        }
        
        if(min1==max1)
            cout<<"exists";
        else
        cout<<"doesnt exist";
}


int main() {
 vector<vector<int>> mat={
      {1,2,3},
      {4,5,6},
      {7,8,9}
  };
  
  saddlepoint(mat);
}