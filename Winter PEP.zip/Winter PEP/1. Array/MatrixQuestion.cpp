#include <iostream>
using namespace std;

void moveZero(int arr[][3], int r, int c) {
    int lastRow = r - 1;
    int lastCol = c - 1;

    for (int i = r - 1; i >= 0; i--) {
        for (int j = c - 1; j >= 0; j--) {
            if (arr[i][j] == 0) {
                int temp = arr[i][j];
                arr[i][j] = arr[lastRow][lastCol];
                arr[lastRow][lastCol] = temp;

                lastCol--;
                if (lastCol < 0) {
                    lastCol = c - 1;
                    lastRow--;
                }
            }
        }
    }
}

int main() {
    int r, c;
    cin >> r >> c;

    int arr[3][3];

    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cin >> arr[i][j];
        }
    }

    moveZero(arr, r, c);

    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }
}
