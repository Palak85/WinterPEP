#include <iostream>
#include <algorithm>
using namespace std;
int main() {
    int r, c;
    cout<<"Enter the number of row and coloum\n";
    cin >> r >> c;

    int matrix[r][c];
    int arr[r * c];
    int idx = 0;
    cout<<"Enter the matrix\n";
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            cin >> matrix[i][j];
            arr[idx++] = matrix[i][j];
        }
    }

    sort(arr, arr + r * c);

    int k;
    cout<<"Enter the how many least element sum you want\n";
    cin >> k;

    int sum = 0;
    for (int i = 0; i < k; i++) {
        sum += arr[i];
    }

    cout << "Least elements: ";
    for (int i = 0; i < k; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    cout << "Sum = " << sum << endl;

    return 0;
}
