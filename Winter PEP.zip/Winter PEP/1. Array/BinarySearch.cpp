#include<iostream>
using namespace std;
int b_s(int arr[],int low,int high,int key){
    if(low > high)
        return -1;

    int mid=(low+high)/2;

    if(arr[mid]>key){
        return b_s(arr,low,mid-1,key);
    }
    else if(arr[mid]<key){
        return b_s(arr,mid+1,high,key);
    }
    else{
        return mid;
    }
}
int main(){
    int arr[]={1,3,4,6,7,9,12,14,16,18,20};
    int low=0;
    int high=10;
    int key= 16;
    int result=b_s(arr, low, high, key);

    if(result != -1)
        cout << "Found at index " << result;
    else
        cout << "Not found";
}