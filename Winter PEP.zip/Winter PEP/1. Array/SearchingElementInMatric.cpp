#include <iostream>
using namespace std;
bool searchMatrix(int matrix[][3], int rows, int cols, int target) {
    int r = 0, c = cols - 1;
    while (r < rows && c >= 0) {
        if (matrix[r][c] == target)
            return true;
        else if (matrix[r][c] > target)
            c--;
        else
            r++;
    }
    return false;
}

int main() {
    int matrix[3][3];
    int target;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> matrix[i][j];
        }
    }

    cin >> target;

    if (searchMatrix(matrix, 3, 3, target))
        cout << "Found" << endl;
    else
        cout << "Not found" << endl;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
