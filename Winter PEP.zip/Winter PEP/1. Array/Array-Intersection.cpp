#include<bits/stdc++.h>
using namespace std;

void intersaction(int n,int m,vector<int>&a,vector<int>&b){
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(a[i]==b[j]){
                cout<<a[i]<<" ";
                break;
            }
        }
    }
}

int main(){
    int n,m;
    cin>>n>>m;
    vector<int>a(n);
    vector<int>b(m);
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    cout<<"Next Array Element "<<endl;
    for(int i=0;i<m;i++){
        cin>>b[i];
    }
    cout<<"Intersection ";
    intersaction(n,m,a,b);
}