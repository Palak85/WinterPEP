#include<bits/stdc++.h>
using namespace std;

void union1(int n,int m ,vector<int>&a,vector<int>&b){
    for(int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    for(int i=0;i<m;i++){
        int j;
        for( j=0;j<n;j++){
            if(b[i]==a[j]){
                break;
            }
            
        }
        if(j==n){
        cout<<b[i]<<" ";
        }
    }

}

int main(){
    int n,m;
    cin>>n>>m;
    vector<int>a(n);
    vector<int>b(m);
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    cout<<"Next Array Element "<<endl;
    for(int i=0;i<m;i++){
        cin>>b[i];
    }
    cout<<endl<<"Union ";
    union1(n,m,a,b);
}