#include<iostream>
using namespace std;
int main(){
    int a[]={1,8,9,4,6,7};
    int k=6;
    int b;
    for(int i=0;i<=5;i++){
        if(a[i]==k){
            b=1;
            break;
        }
    }
    if(b==1){
        cout<<k;
    }
}