#include <iostream>
#include <vector>
using namespace std;

void checkfreq(vector<int> arr){
    int n = arr.size();

    for(int i = 0; i < n; i++){

        int count = 0;
        bool alreadyCounted = false;

        for(int k = 0; k < i; k++){
            if(arr[i] == arr[k]){
                alreadyCounted = true;
                break;
            }
        }

        if(alreadyCounted)
            continue;

        for(int j = 0; j < n; j++){
            if(arr[i] == arr[j])
                count++;
        }

        cout << arr[i] << " -> " << count << endl;
    }
}

int main() {
    vector<int> arr = {1,2,4,1,3,1,9};
    checkfreq(arr);
}