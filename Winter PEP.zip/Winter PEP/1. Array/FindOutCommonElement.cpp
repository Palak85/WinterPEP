#include<iostream>
using namespace std;
int main(){
    int arr1[]={3,5,8,9};
    int arr2[]={5,8,9,10,11};
    int temp[];
    int k=0;
    for(int i=0;i<4;i++){
        for(int j=0;j<5;j++){
            if (arr1[i]=arr2[j]){
                temp[k++]=arr1[i];
            }
        }
    }
    for(int i=0;i<3;i++){
        cout<<temp[i]<<" ";
    }
}