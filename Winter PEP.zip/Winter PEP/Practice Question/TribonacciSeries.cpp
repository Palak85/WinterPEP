// #include<iostream>
// using namespace std;
// int fib(int n){
//     if(n<=2){
//         return n;
//     }
//     return fib(n-1)+fib(n-2)+fib(n-3);
// }

// int main(){
//     int n=10;
//     for(int i=0;i<n;i++){
//         cout<<fib(i)<<" ";
//     }
// }


//Tabulation method.........
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cout<<"Enter the number of term you want: ";
//     cin>>n;

//      int tri[n+1];
//      tri[0]=0;
//      tri[1]=1;
//      tri[2]=2;

//      for(int i=3; i<=n;i++){
//         tri[i]=tri[i-1]+tri[i-2]+tri[i-3];
//      }

//      for(int i= 0;i<n;i++){
//       cout<<tri[i]<<" ";
//      }
//      return 0;
// }


//Memorization method...

#include<iostream>
using namespace std;

int tri(int n, int dp[]){
    if(n <= 3)
        return n;

    if(dp[n] != -1)
        return dp[n];

    dp[n] = tri(n-1, dp) + tri(n-2, dp) + tri(n-3, dp);
    return dp[n];
}

int main(){
    int n = 7;

    int dp[n+1];

    for(int i = 0; i <= n; i++)
        dp[i] = -1;

    for(int i = 1; i <= n; i++){
        cout << tri(i, dp) << " ";
    }

    return 0;
}
