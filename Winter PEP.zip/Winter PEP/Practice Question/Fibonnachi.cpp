// #include<iostream>
// using namespace std;

// int fib(int n){
//     if(n<=1){
//         return n;
//     }
//     return fib(n-1)+fib(n-2);
    

// }
// int main(){
//     int n=5;
//     for(int i=0;i<n;i++){
//         cout<<fib(i)<<" ";
//     }
// }



//Tabulation method.........
// #include<iostream>
// using namespace std;
// int main(){
//     int n;
//     cout<<"Enter the number of term you want: ";
//     cin>>n;

//      int fib[n+1];
//      fib[0]=0;
//      fib[1]=1;

//      for(int i=2; i<=n;i++){
//         fib[i]=fib[i-1]+fib[i-2];
//      }

//      for(int i= 0;i<n;i++){
//       cout<<fib[i]<<" ";
//      }
//      return 0;
// }


//Memoriztion method.....
#include<iostream>
using namespace std;

int fib(int n, int dp[]){
    if(n == 0)
        return 0;
    if(n == 1)
        return 1;

    if(dp[n] != -1)
        return dp[n];

    dp[n] = fib(n-1, dp) + fib(n-2, dp);
    return dp[n];
}

int main(){
    int n = 10;

    int dp[n+1];

    for(int i = 0; i <= n; i++)
        dp[i] = -1;

    for(int i = 0; i <= n; i++)
        cout << fib(i, dp) << " ";

    return 0;
}
