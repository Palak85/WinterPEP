#include<iostream>
using namespace std;
int rev=0;
void rever(int n){
    if(n==0){
    return ;
}
    int rem=n%10;
    rev=rev*10+rem;
    rever(n/10); 
};

int main(){
    int n;
    cin>>n;
    rever(n);
    cout<<rev;
}