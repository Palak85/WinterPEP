class TrieNode:
    def __init__(self):
        self.child = {}
        self.end = False
        
class Trie:
    def __init__(self):
        self.root = TrieNode()
        
    def insert(self, word):   
        curr_node = self.root
        for char in word:
            if char not in curr_node.child:
                curr_node.child[char] = TrieNode()
            curr_node = curr_node.child[char]
        curr_node.end = True
    
    def search(self, word):   
        curr_node = self.root
        for char in word:
            if char not in curr_node.child:
                return False
            curr_node = curr_node.child[char]
        if curr_node.end:
            return True
        return False
    
    def remove(self, word):
        if not self.search(word):
            print("Word not found")
            return
        
        curr_node = self.root
        stack = []
        
        for char in word:
            stack.append((curr_node, char))
            curr_node = curr_node.child[char]
        curr_node.end = False

        while stack:
            node, char = stack.pop()
            child_node = node.child[char]
            if not child_node.child and not child_node.end:
                del node.child[char]
            else:
                break  
        print("Word removed")

        
t1 = Trie()
t1.insert("APPLE")
t1.insert("APPLICATION")
t1.insert("APP")
print(t1.search("APPLE"))
t1.remove("APPLE")