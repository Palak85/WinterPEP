#include <iostream>
using namespace std;

const int ALPHABET_SIZE = 26;

struct TrieNode {
    TrieNode* children[ALPHABET_SIZE];
    bool isEndOfWord;

    TrieNode() {
        isEndOfWord = false;
        for(int i = 0; i < ALPHABET_SIZE; i++)
            children[i] = nullptr;
    }
};

// ================= INSERT =================
void insert(TrieNode* root, string key)
{
    TrieNode* current = root;

    for(int i = 0; i < key.length(); i++)
    {
        int index = key[i] - 'a';

        if(current->children[index] == nullptr)
            current->children[index] = new TrieNode();

        current = current->children[index];
    }

    current->isEndOfWord = true;
}

// ================= SEARCH FULL WORD =================
bool searchWord(TrieNode* root, string key)
{
    TrieNode* current = root;

    for(int i = 0; i < key.length(); i++)
    {
        int index = key[i] - 'a';

        if(current->children[index] == nullptr)
            return false;

        current = current->children[index];
    }

    return current->isEndOfWord;
}

// ================= SEARCH PREFIX =================
bool searchPrefix(TrieNode* root, string prefix)
{
    TrieNode* current = root;

    for(int i = 0; i < prefix.length(); i++)
    {
        int index = prefix[i] - 'a';

        if(current->children[index] == nullptr)
            return false;

        current = current->children[index];
    }

    return true;
}

// ================= CHECK IF NODE HAS NO CHILDREN =================
bool isEmpty(TrieNode* node)
{
    for(int i = 0; i < ALPHABET_SIZE; i++)
    {
        if(node->children[i] != nullptr)
            return false;
    }
    return true;
}



bool deleteHelper(TrieNode* node, string key, int depth)
{
    if(node == nullptr)
        return false;

    if(depth == key.length())
    {
        if(node->isEndOfWord == false)
            return false;

        node->isEndOfWord = false;

        return isEmpty(node);
    }

    int index = key[depth] - 'a';

    if(deleteHelper(node->children[index], key, depth + 1))
    {
        delete node->children[index];
        node->children[index] = nullptr;

        return (!node->isEndOfWord && isEmpty(node));
    }

    return false;
}

void printAllWords(TrieNode* root,int &count,string word)
{   
    if(root == nullptr)
        return;

    if(root->isEndOfWord){
        cout << word << endl;
        count++;
    }

    for(int i = 0; i < ALPHABET_SIZE; i++)
    {
        if(root->children[i] != nullptr)
        {
            char ch = 'a' + i;
            printAllWords(root->children[i],count,word + ch);
        }
    }
}
// ================= MAIN =================
int main()
{
    TrieNode* root = new TrieNode();

    insert(root, "apple");
    insert(root, "app");
    insert(root, "bat");

    cout << "Search apple: " << searchWord(root, "apple") << endl;
    cout << "Search app: " << searchWord(root, "app") << endl;
    cout << "Search ap: " << searchPrefix(root, "ap") << endl;

    root = deleteWord(root, "apple");

    cout << "After deleting apple:" << endl;
    cout << "Search apple: " << searchWord(root, "apple") << endl;
    cout << "Search app: " << searchWord(root, "app") << endl;

    cout << "All words in Trie:" << endl;
    int count=0;
    printAllWords(root,count,"");
    cout<<count;

    return 0;
}