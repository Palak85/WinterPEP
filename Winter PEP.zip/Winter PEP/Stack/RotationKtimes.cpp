#include <iostream>
#include <stack>
using namespace std;

stack<int> rotatektimes(stack<int> st,int k){

    int n = st.size();
    k = k % n;

    for(int i=0;i<k;i++){

        int topElement = st.top();
        st.pop();

        stack<int> temp;

        while(!st.empty()){
            temp.push(st.top());
            st.pop();
        }

        st.push(topElement);

        while(!temp.empty()){
            st.push(temp.top());
            temp.pop();
        }
    }

    return st;
}

int main() {

    stack<int> st;

    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);

    int k=1;

    stack<int> result = rotatektimes(st,k);

    while(!result.empty()){
        cout<<result.top()<<" ";
        result.pop();
    }
}