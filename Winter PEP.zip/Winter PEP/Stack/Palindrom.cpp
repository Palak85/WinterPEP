#include <iostream>
#include <stack>
using namespace std;

bool checkPalindrome(string &s, int i, stack<char>& st)
{
    if(i == s.length())
        return true;

    st.push(s[i]);

    bool res = checkPalindrome(s, i + 1, st);

    if(st.top() != s[s.length() - i - 1])
        return false;

    st.pop();

    return res;
}

int main(){

    string s = "malayalam";
    stack<char> st;

    if(checkPalindrome(s, 0, st)){
        cout << "Palindrome";
    }
    else{
        cout << "Not Palindrome";
    }
}