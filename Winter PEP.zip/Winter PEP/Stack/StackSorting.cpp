#include <iostream>
#include <stack>
using namespace std;

void sortStack(stack<int> &st) {

    stack<int> temp;

    while(!st.empty()) {

        int curr = st.top();
        st.pop();

        while(!temp.empty() && temp.top() > curr) {
            st.push(temp.top());
            temp.pop();
        }

        temp.push(curr);
    }

    while(!temp.empty()) {
        st.push(temp.top());
        temp.pop();
    }
}

int main() {

    stack<int> st;

    st.push(3);
    st.push(1);
    st.push(4);
    st.push(2);

    sortStack(st);

    while(!st.empty()) {
        cout << st.top() << " ";
        st.pop();
    }
}