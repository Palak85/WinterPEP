#include <iostream>
#include <stack>
using namespace std;

void mergeStacks(stack<int>& st, stack<int>& left, stack<int>& right)
{
    stack<int> temp;

    while(!left.empty() && !right.empty())
    {
        if(left.top() <= right.top())
        {
            temp.push(left.top());
            left.pop();
        }
        else
        {
            temp.push(right.top());
            right.pop();
        }
    }

    while(!left.empty())
    {
        temp.push(left.top());
        left.pop();
    }

    while(!right.empty())
    {
        temp.push(right.top());
        right.pop();
    }

    while(!temp.empty())
    {
        st.push(temp.top());
        temp.pop();
    }
}

void mergeSort(stack<int>& st)
{
    if(st.size() <= 1)
        return;

    stack<int> left, right;

    int mid = st.size() / 2;

    for(int i = 0; i < mid; i++)
    {
        left.push(st.top());
        st.pop();
    }

    while(!st.empty())
    {
        right.push(st.top());
        st.pop();
    }

    mergeSort(left);
    mergeSort(right);

    mergeStacks(st, left, right);
}

int main()
{
    stack<int> st;

    st.push(30);
    st.push(10);
    st.push(50);
    st.push(20);
    st.push(40);

    mergeSort(st);

    while(!st.empty())
    {
        cout << st.top() << " ";
        st.pop();
    }
}