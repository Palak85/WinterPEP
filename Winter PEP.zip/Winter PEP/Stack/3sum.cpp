#include <iostream>
#include <stack>
using namespace std;

void twoSumStack(stack<int> st, int target) {

    stack<int> temp;

    while(!st.empty()) {

        int first = st.top();
        st.pop();

        stack<int> copy = st;  // remaining elements

        while(!copy.empty()) {
            int second = copy.top();
            copy.pop();

            stack<int> copy1 = copy;

            while(!copy1.empty()){
                int third=copy1.top();
                copy1.pop();

            if(first + second+third == target) {
                cout << "Pair Found: "
                     << first << " " << second<<" "<<third;
                return;
            }
        }
        }

        temp.push(first);
    }

    cout << "No pair found";
}

int main() {

    stack<int> st;

    st.push(15);
    st.push(7);
    st.push(2);
    st.push(15);
    st.push(1);
    st.push(5);
    st.push(10);

    int target = 16;

    twoSumStack(st, target);
}