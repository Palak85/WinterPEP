#include <iostream>
#include <stack>
using namespace std;

stack<int> mergeSortedStacks(stack<int> s1, stack<int> s2)
{
    stack<int> temp;

    while(!s1.empty() && !s2.empty())
    {
        if(s1.top() > s2.top())
        {
            temp.push(s1.top());
            s1.pop();
        }
        else
        {
            temp.push(s2.top());
            s2.pop();
        }
    }

    while(!s1.empty())
    {
        temp.push(s1.top());
        s1.pop();
    }

    while(!s2.empty())
    {
        temp.push(s2.top());
        s2.pop();
    }

    stack<int> result;

    while(!temp.empty())
    {
        result.push(temp.top());
        temp.pop();
    }

    return result;
}

int main()
{
    stack<int> s1, s2;

    s1.push(1);
    s1.push(3);
    s1.push(5);

    s2.push(2);
    s2.push(4);
    s2.push(6);

    stack<int> merged = mergeSortedStacks(s1, s2);

    while(!merged.empty())
    {
        cout << merged.top() << " ";
        merged.pop();
    }

    return 0;
}