#include <iostream>
#include <stack>
#include <cmath>
using namespace std;

void moveDisk(stack<int>& from, stack<int>& to, char s, char d)
{
    int pole1Top = from.empty() ? INT_MAX : from.top();
    int pole2Top = to.empty() ? INT_MAX : to.top();

    if(pole1Top < pole2Top)
    {
        to.push(pole1Top);
        from.pop();
        cout << "Move disk " << pole1Top << " from " << s << " to " << d << endl;
    }
    else
    {
        from.push(pole2Top);
        to.pop();
        cout << "Move disk " << pole2Top << " from " << d << " to " << s << endl;
    }
}

int main()
{
    int n = 4;

    stack<int> A, B, C;

    for(int i = n; i >= 1; i--)
        A.push(i);

    char s = 'A', h = 'B', d = 'C';

    if(n % 2 == 0)
        swap(h, d);

    int totalMoves = pow(2, n) - 1;

    for(int i = 1; i <= totalMoves; i++)
    {
        if(i % 3 == 1)
            moveDisk(A, C, s, d);
        else if(i % 3 == 2)
            moveDisk(A, B, s, h);
        else
            moveDisk(B, C, h, d);
    }
}