#include <iostream>
#include <stack>
#include <queue>
using namespace std;

queue <int> q;

void push1(int n)
{
   
    int m=q.size();
     q.push(n);
    
    for(int i=0;i<m;i++)
    {
    q.push(q.front());
    q.pop();
    }
    
    cout<<"push successful"<<n;
    cout<<endl;
}


void pop1()
{
   
    cout<<"successfully deque"<<q.front();
    cout<<endl;
    q.pop();
}


void top1()
{
    cout<<q.front();
    cout<<endl;
}

int main()
{
   push1(10);
   push1(20);
   push1(30);
   push1(40);
   push1(50);
   top1();
   push1(60);
   top1();
   pop1();
   pop1();
   pop1();
   top1();
   
    
}