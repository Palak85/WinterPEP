#include <iostream>
#include <stack>
using namespace std;

void twoSumStack(stack<int> st, int target) {

    stack<int> temp;

    while(!st.empty()) {

        int first = st.top();
        st.pop();

        stack<int> copy = st;  // remaining elements

        while(!copy.empty()) {
            int second = copy.top();
            copy.pop();

            if(first + second == target) {
                cout << "Pair Found: "
                     << first << " " << second;
                return;
            }
        }

        temp.push(first);
    }

    cout << "No pair found";
}

int main() {

    stack<int> st;

    st.push(15);
    st.push(7);
    st.push(2);
    st.push(15);

    int target = 9;

    twoSumStack(st, target);
}