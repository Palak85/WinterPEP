#include <iostream>
#include <stack>
using namespace std;

stack<int> st;
stack<int> minSt;

void push(int x) {
    st.push(x);

    if(minSt.empty() || x <= minSt.top())
        minSt.push(x);
}

void pop() {
    if(st.empty()) return;

    if(st.top() == minSt.top())
        minSt.pop();

    st.pop();
}

int top() {
    if(st.empty()) return -1;   // safety
    return st.top();
}

int getMin() {
    if(minSt.empty()) return -1;  // safety
    return minSt.top();
}

int main() {
    push(5);
    push(2);
    push(7);
    push(3);

    cout << "Min: " << getMin() << endl;  // 2

    pop();
    cout << "Min after pop: " << getMin() << endl;  // 3
}