#include <iostream>
#include <queue>
using namespace std;

queue<int> mergeSortedQueues(queue<int> s1, queue<int> s2)
{
    queue<int> temp;

    while(!s1.empty() && !s2.empty())
    {
        if(s1.front() < s2.front())
        {
            temp.push(s1.front());
            s1.pop();
        }
        else
        {
            temp.push(s2.front());
            s2.pop();
        }
    }

    while(!s1.empty())
    {
        temp.push(s1.front());
        s1.pop();
    }

    while(!s2.empty())
    {
        temp.push(s2.front());
        s2.pop();
    }

    queue<int> result;

    while(!temp.empty())
    {
        result.push(temp.front());
        temp.pop();
    }

    return result;
}

int main()
{
    queue<int> s1, s2;

    s1.push(1);
    s1.push(3);
    s1.push(5);

    s2.push(2);
    s2.push(4);
    s2.push(6);

    queue<int> merged = mergeSortedQueues(s1, s2);

    while(!merged.empty())
    {
        cout << merged.front() << " ";
        merged.pop();
    }

    return 0;
}