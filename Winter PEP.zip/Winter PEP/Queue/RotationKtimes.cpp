#include <iostream>
#include <queue>
#include <stack>
using namespace std;

void reverseK(queue<int> &q, int k)
{
    if(k <= 0 || k > q.size())
        return;

    stack<int> st;

    for(int i = 0; i < k; i++)
    {
        st.push(q.front());
        q.pop();
    }

    while(!st.empty())
    {
        q.push(st.top());
        st.pop();
    }

    int t = q.size() - k;

    for(int i = 0; i < t; i++)
    {
        q.push(q.front());
        q.pop();
    }
}

int main()
{
    queue<int> q;

    q.push(1);
    q.push(2);
    q.push(3);
    q.push(4);
    q.push(5);

    int k = 3;

    reverseK(q, k);

    while(!q.empty())
    {
        cout << q.front() << " ";
        q.pop();
    }
}
