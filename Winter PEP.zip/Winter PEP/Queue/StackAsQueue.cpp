#include <iostream>
#include <stack>
using namespace std;

stack <int> s1,s2;

void enqueue1(int n)
{
    s1.push(n);
    cout<<"enqueue successful"<<s1.top();
    cout<<endl;
}


void dequeue1()
{   
    while(!s1.empty())
    {
          s2.push(s1.top());
          s1.pop();
    }
    
  cout<<s2.top()<<"dequeue successful";
  cout<<endl;
  s2.pop();
  
}


int main()
{
    enqueue1(10);
    enqueue1(20);
    enqueue1(30);
    enqueue1(40);
    enqueue1(50);
    enqueue1(60);
    
    dequeue1();
    cout<<s2.top();
    dequeue1();
    cout<<s2.top();
    dequeue1();
    
   
    
}