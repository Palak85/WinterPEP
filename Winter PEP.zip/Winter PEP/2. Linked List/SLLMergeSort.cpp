#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* insertEnd(Node* head, int x) {
    if (head == NULL)
        return new Node{x, NULL};

    head->next = insertEnd(head->next, x);
    return head;
}

Node* createList() {
    int n, x;
    cin >> n;

    Node* head = NULL;
    while (n>0) {
        cin >> x;
        head = insertEnd(head, x);
        n--;
    }
    return head;
}

Node* getMiddle(Node* head) {
    Node* slow = head;
    Node* fast = head->next;

    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

Node* merge(Node* a, Node* b) {
    if (a == NULL) return b;
    if (b == NULL) return a;

    if (a->data < b->data) {
        a->next = merge(a->next, b);
        return a;
    } else {
        b->next = merge(a, b->next);
        return b;
    }
}

Node* mergeSort(Node* head) {
    if (head == NULL || head->next == NULL)
        return head;

    Node* mid = getMiddle(head);
    Node* second = mid->next;
    mid->next = NULL;

    return merge(mergeSort(head), mergeSort(second));
}

void print(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

int main() {
    Node* head = createList();
    head = mergeSort(head);
    print(head);
}
