#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertatend(Node* &head, int val) {
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

Node* createList() {
    int n;
    cout<<"Number of Node: ";
    cin >> n;

    Node* head = NULL;
    for (int i = 0; i < n; i++) {
        int x;
        cout<<"Enter "<<i<<" the element: ";
        cin >> x;
        insertatend(head, x);
    }
    return head;
}

bool ispresent(Node* head, int val) {
    while (head != NULL) {
        if (head->data == val)
            return true;
        head = head->next;
    }
    return false;
}

Node* intersection(Node* head1, Node* head2) {
    Node* h3 = NULL;

    Node* t1 = head1;
    while (t1 != NULL) {
        Node* t2 = head2;

        while (t2 != NULL) {
            if (t1->data == t2->data) {
                bool present=ispresent(h3, t1->data);
                if (present==false) {
                    insertatend(h3, t1->data);
                }
            }
            t2 = t2->next;
        }
        t1 = t1->next;
    }
    return h3;
}

void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

int main() {
    Node* head1 = createList();
    Node* head2 = createList();

    Node* inter = intersection(head1, head2);
    cout<<"The common element is: ";
    printList(inter);
}
