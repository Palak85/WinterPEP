#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int Count(Node* head) {
    int count = 0;
    while (head != NULL) {
        count++;
        head = head->next;
    }
    return count;
}

void sortList(Node* head) {
    int n = Count(head);
    Node* t1;
    Node* t2;
    int temp;

    for (int i = 0; i < n; i++) {
        t1 = head;
        t2 = head->next;

        while (t2 != NULL) {
            if (t1->data > t2->data) {
                temp = t1->data;
                t1->data = t2->data;
                t2->data = temp;
            }
            t1 = t1->next;
            t2 = t2->next;
        }
    }
}

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

int main() {
    Node* head = createList();
    sortList(head);
    printList(head);
}
