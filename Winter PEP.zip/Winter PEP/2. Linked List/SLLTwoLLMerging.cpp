//HERE I AM MERGING TWO SORTED LINKED LISTAND I TRY TO GET NEW SORTED LINKED LIST
#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
    
    Node(int x){
        data=x;
        next=nullptr;
    
    }
};

void insertrear(Node* &head,int data)
{
    Node* new_node=new Node(data);
    if(head==nullptr)
    {
        head=new_node;
    }
    else
    {
        Node* temp=head;
        while(temp->next!=nullptr)
        {
            temp=temp->next;
        }
        temp->next=new_node;
        
}
}


void display1(Node* &head)
{
    Node* tem=head;
    while(tem!=nullptr)
    {   
        cout<<tem->data<<" ";
        tem=tem->next;
    }
    cout<<endl;
}

void merge(Node* &head1, Node* &head2,Node* &head3)
{
    Node* a=head1;
    Node* b=head2;
    
    while(a!=nullptr && b!=nullptr)
    {
    if(a->data < b->data)
    {
        insertrear(head3,a->data);
        a=a->next;
    }
    else
    {
        insertrear(head3,b->data);
        b=b->next;
    }
    }
    
        while(a!=nullptr)
        {
        insertrear(head3,a->data);
        a=a->next;
        }
        
        while(b!=nullptr)
        {
        insertrear(head3,b->data);
        b=b->next;
        }
        
    display1(head3);
}


int main() { 
    Node* head1=nullptr;
    Node* head2=nullptr;    
    Node* head3=nullptr;
    
    
    insertrear(head1,30);
    insertrear(head1,50);
    insertrear(head1,100);
    
    insertrear(head2,70);
    insertrear(head2,120);
    insertrear(head2,130);
    insertrear(head2,150);
    insertrear(head2,195);

    display1(head1);
    display1(head2);
    merge(head1,head2,head3);


    return 0;
}