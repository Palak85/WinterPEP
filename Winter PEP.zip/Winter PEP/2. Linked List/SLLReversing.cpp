#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void reverse1(Node* &head) {
    Node* prev = NULL;
    Node* curr = head;
    Node* next = NULL;

    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    printList(head);

    reverse1(head);

    printList(head);
    cout<<head->next->next->next->data;
}


// #include<iostream>
// using namespace std;
// struct Node{
//     int data;
//     Node* next;
// };

// void Reversell(Node* head){
//     Node* prev=NULL;
//     Node* curr=head;
//     Node* upcom=NULL;

//     while(curr!=NULL){
//         upcom=curr->next;
//         curr->next=prev;
//         prev=curr;
//         curr=upcom;
//     }
//     head=prev;
//     Node* temp=head;
//     while(temp!=NULL){
//         cout<<temp->data<<" ";
//         temp=temp->next;
//     }
    
//     return ;
// }



// Node* createll(){
//     Node* head=NULL;
//     Node* tail=NULL;
//     int val;
//     while(cin>>val){
//         Node* newNode=new Node();
//         newNode->data=val;
//         newNode->next=NULL;

//         if(head==NULL){
//             head=newNode;
//             tail=newNode;
//         }
//         else{
//             tail->next=newNode;
//             tail=newNode;
//         }
//     }
//     return head;
// }
// int main(){
//     Node* head=createll();
//     Reversell(head);
// }