#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
}

void removealternate(Node* &head)
{
    if (head == NULL)
        return;
    Node* head1 = head;

    while (head1 != NULL && head1->next != NULL) {
        Node* temp = head1->next;   
        head1->next = temp->next;  
        delete temp;                
        head1 = head1->next;
    }
}
int main() {
    Node* head = createList();
    printList(head);
    cout<<endl;
    removealternate(head);
    printList(head);
}
