

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertatbeg(Node* &head, Node* &tail,int data){
    Node* new_node=new Node(data);

    if (head == nullptr) {
        head = new_node;
        tail = new_node;
        tail->next = head;
    } else {
        new_node->next=head;
        head=new_node;
        tail->next=head;
    }

}

void display(Node* head) {
    if (head == nullptr)
        return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

int main() {
    Node* head = nullptr;
    Node* tail = nullptr;

    insertatbeg(head, tail, 30);
    insertatbeg(head, tail, 40);
    insertatbeg(head, tail, 50);

    display(head);
}
