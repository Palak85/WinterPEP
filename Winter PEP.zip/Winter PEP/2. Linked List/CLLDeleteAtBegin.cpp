#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertatrear(Node* &head, Node* &tail, int data) {
    Node* new_node = new Node(data);

    if (head == nullptr) {
        head = new_node;
        tail = new_node;
        tail->next = head;
    } else {
        tail->next = new_node;
        tail = new_node;
        tail->next = head;
    }
}

void deleteatbegin(Node* &head, Node* &tail){
    if(head==nullptr){
        cout<<"Linked List is empty";
        return;
    }

    else if(head==tail){
        delete head;
        head=nullptr;
        tail=nullptr;
        cout<<"Now Linked List is Empty because you linked list had only one node";
        return ;
    }

    else{
        Node* temp=head;
        head=head->next;
        tail->next=head;
        delete temp;
    }
}

void display(Node* head) {
    if (head == nullptr)
        return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

int main() {
    Node* head = nullptr;
    Node* tail = nullptr;

    insertatrear(head, tail, 10);
    insertatrear(head, tail, 20);
    insertatrear(head, tail, 30);
    insertatrear(head, tail, 40);
    insertatrear(head, tail, 50);

    deleteatbegin(head,tail);
    
    display(head);
}