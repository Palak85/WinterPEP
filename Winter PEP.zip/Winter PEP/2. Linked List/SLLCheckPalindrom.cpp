#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

bool palindrom(Node* head) {
    if (head == NULL || head->next == NULL)
        return true;

    Node* slow = head;
    Node* fast = head;

    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }

    Node* prev = NULL;
    Node* curr = slow->next;
    Node* next = NULL;
    slow->next = NULL;

    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }

    Node* first = head;
    Node* second = prev;

    while (second != NULL) {
        if (first->data != second->data)
            return false;
        first = first->next;
        second = second->next;
    }

    return true;
}

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

int main() {
    Node* head = createList();

    if (palindrom(head))
        cout << "It's valid palindrome";
    else
        cout << "It's not palindrome";
}
