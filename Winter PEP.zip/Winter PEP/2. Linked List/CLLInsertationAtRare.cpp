// #include <iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* next;
// };

// Node* createList(Node* &tail) {
//     Node* head = NULL;
//     tail = NULL;

//     int n;
//     cin >> n;

//     for (int i = 0; i < n; i++) {
//         int val;
//         cin >> val;

//         Node* newNode = new Node();
//         newNode->data = val;
//         newNode->next = NULL;

//         if (head == NULL) {
//             head = newNode;
//             tail = newNode;
//             tail->next = head;  
//         } else {
//             tail->next = newNode;
//             tail = newNode;
//             tail->next = head;  
//         }
//     }
//     return head;
// }

// void printList(Node* head) {
//     if (head == NULL)
//         return;

//     Node* temp = head;
//     do {
//         cout << temp->data << " ";
//         temp = temp->next;
//     } while (temp != head);

//     cout << endl;
// }

// int main() {
//     Node* tail;
//     Node* head = createList(tail);

//     printList(head);

//     return 0;
// }


#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertatrear(Node* &head, Node* &tail, int data) {
    Node* new_node = new Node(data);

    if (head == nullptr) {
        head = new_node;
        tail = new_node;
        tail->next = head;
    } else {
        tail->next = new_node;
        tail = new_node;
        tail->next = head;
    }
}

void display(Node* head) {
    if (head == nullptr)
        return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

int main() {
    Node* head = nullptr;
    Node* tail = nullptr;

    insertatrear(head, tail, 10);
    insertatrear(head, tail, 20);
    insertatrear(head, tail, 30);
    insertatrear(head, tail, 40);
    insertatrear(head, tail, 50);
    
    display(head);
}
