#include<iostream>
using namespace std;
struct Node{
    int data;
    Node* next;
};

int Input()

int main(){
    Node* head = creatLL
}
