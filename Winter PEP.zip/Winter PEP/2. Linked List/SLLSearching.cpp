#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void searching(Node* &head,int n){
    Node* temp=head;
    while(temp->data!=n){
        if(temp->data==n){
            cout<<"data found";
        }
        else{
            cout<<"Dta not found";
        }
    }
    return ;
}

int main() {
    Node* head = new Node();
    head->data = 10;
    head->next = NULL;

    Node* second = new Node();
    second->data = 20;
    second->next = NULL;

    Node* third = new Node();
    third->data = 30;
    third->next = NULL;

    head->next = second;
    second->next = third;

    int n;
    cin>>n;
    searching(head,n);

    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
}
