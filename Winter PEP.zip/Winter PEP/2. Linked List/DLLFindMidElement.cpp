#include<iostream>
using namespace std;
class Node{
    public:
    int data;
    Node*next;
    Node*prev;
    Node(int x){
        data=x;
        next=nullptr;
        prev=nullptr;
    }
};
void insertrare(Node* &h,Node* &t,int x){
    Node* newNode=new Node(x);
    if(h==NULL && t==NULL){
        h=newNode;
        t=newNode;
    }
    else{
        t->next=newNode;
        newNode->prev=t;
        t=newNode;
    }
}
void display(Node *head){
    Node *temp=head;
    while(temp!=nullptr){
        cout<<temp->data<<"->";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

void findMiddle(Node* h,Node* t){
    while(h != t && h->next != t){
        h=h->next;
        t=t->prev;
    }
    cout << "Middle element: "<<h->data<< endl;
}

int main(){
    Node* head=nullptr;
    Node* tail=nullptr;

    insertrare(head,tail,80);
    insertrare(head,tail,50);
    insertrare(head,tail,20);
    insertrare(head,tail,10);
    display(head);

    findMiddle(head, tail);
    return 0;
}
 
 
 
