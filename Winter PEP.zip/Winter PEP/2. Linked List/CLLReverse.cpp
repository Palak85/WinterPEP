#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertatrear(Node* &head, Node* &tail, int data) {
    Node* new_node = new Node(data);

    if (head == nullptr) {
        head = new_node;
        tail = new_node;
        tail->next = head;
    } else {
        tail->next = new_node;
        tail = new_node;
        tail->next = head;
    }
}
void Reverse(Node* &head, Node* &tail){
    tail->next=NULL;
    Node* prev = NULL;
    Node* curr = head;
    Node* next = NULL;

    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;

    tail=head;
    while(tail->next!=NULL){
        tail=tail->next;
    }
    tail->next=head;

}
void display(Node* head) {
    if (head == nullptr)
        return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

int main() {
    Node* head = nullptr;
    Node* tail = nullptr;

    insertatrear(head, tail, 10);
    insertatrear(head, tail, 20);
    insertatrear(head, tail, 30);
    insertatrear(head, tail, 40);
    insertatrear(head, tail, 50);
    
    display(head);

    Reverse(head,tail);
    display(head);
}