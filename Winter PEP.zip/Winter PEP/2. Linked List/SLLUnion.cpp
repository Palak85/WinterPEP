#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertEnd(Node* &head, int val) {
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }
    temp->next = newNode;
}

bool ispresent(Node* head, int val) {
    while (head != NULL) {
        if (head->data == val)
            return true;
        head = head->next;
    }
    return false;
}

Node* Union(Node* head1, Node* head2) {
    Node* h3= NULL;

    Node* temp = head1;
    while (temp != NULL) {
        bool present=ispresent(h3, temp->data);
        if (present==false) {
            insertEnd(h3, temp->data);
        }
        temp = temp->next;
    }

    temp = head2;
    while (temp != NULL) {
        bool present=ispresent(h3, temp->data);
        if (present==false) {
            insertEnd(h3, temp->data);
        }
        temp = temp->next;
    }

    return h3;
}

void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

Node* createList() {
    int n;
    cout<<"Enter the number of node: ";
    cin >> n;

    Node* head = NULL;
    for (int i = 0; i < n; i++) {
        int x;
        cout<<"Enter the "<<i<<" data: ";
        cin >> x;
        insertEnd(head, x);
    }
    return head;
}

int main() {
    Node* head1 = createList();
    Node* head2 = createList();

    Node* u = Union(head1, head2);
    printList(u);
}
