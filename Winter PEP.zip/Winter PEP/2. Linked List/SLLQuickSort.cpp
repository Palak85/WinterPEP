#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertAtEnd(Node*& head, int x) {
    Node* newNode = new Node(x);

    if (!head) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next)
        temp = temp->next;

    temp->next = newNode;
}

Node* getTail(Node* head) {
    while (head && head->next)
        head = head->next;
    return head;
}

Node* quickSort(Node* head) {
    // Base case
    if (!head || !head->next)
        return head;

    // Pivot is head
    Node* pivot = head;

    Node* smallerHead = nullptr;
    Node* smallerTail = nullptr;
    Node* greaterHead = nullptr;
    Node* greaterTail = nullptr;

    Node* cur = head->next;

    // Partition step
    while (cur) {
        Node* nextNode = cur->next;
        cur->next = nullptr;

        if (cur->data < pivot->data) {
            if (!smallerHead) {
                smallerHead = smallerTail = cur;
            } else {
                smallerTail->next = cur;
                smallerTail = cur;
            }
        } else {
            if (!greaterHead) {
                greaterHead = greaterTail = cur;
            } else {
                greaterTail->next = cur;
                greaterTail = cur;
            }
        }

        cur = nextNode;
    }

    // Recursive sorting
    smallerHead = quickSort(smallerHead);
    greaterHead = quickSort(greaterHead);

    // Join lists
    pivot->next = greaterHead;

    if (!smallerHead)
        return pivot;

    Node* tail = getTail(smallerHead);
    tail->next = pivot;

    return smallerHead;
}

void display(Node* head) {
    while (head) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

int main() {
    Node* head = nullptr;

    insertAtEnd(head, 5);
    insertAtEnd(head, 8);
    insertAtEnd(head, 2);
    insertAtEnd(head, 3);
    insertAtEnd(head, 9);

    cout << "Before Sorting: ";
    display(head);

    head = quickSort(head);

    cout << "After Sorting: ";
    display(head);

    return 0;
}