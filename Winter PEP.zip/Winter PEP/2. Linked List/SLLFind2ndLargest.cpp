#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

void secondlargest(Node* head) {
    if (head == NULL || head->next == NULL) {
        cout << "Not possible\n";
        return;
    }

    int max1 = -1e9;
    int max2 = -1e9;

    Node* temp = head;
    while (temp != NULL) {
        if (temp->data > max1) {
            max2 = max1;
            max1 = temp->data;
        } else if (temp->data < max1 && temp->data > max2) {
            max2 = temp->data;
        }
        temp = temp->next;
    }

    cout << max2 << endl;
}

void printList(Node* head) {
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
}

int main() {
    Node* head = createList();

    secondlargest(head);
    printList(head);
}
