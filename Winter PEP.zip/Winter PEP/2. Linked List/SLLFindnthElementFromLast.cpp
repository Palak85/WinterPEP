#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    while(tail!NULL){
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

int Count(Node* head){
    int c=0;
    Node* temp =head;
    while(temp!=NULL){
        temp=temp->next;
        c++;
    }
    return c;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
}

void findnthelement(Node* head, int n){
    int p = Count(head);

    if (n > p || n <= 0) {
        cout << "Invalid n";
        return;
    }

    int k = p - n;
    Node* temp = head;

    while(k > 0){
        temp = temp->next;
        k--;
    }

    cout << temp->data << endl;
}

int main() {
    int n;
    cin>>n;

    Node* head = createList();
    printList(head);
    
    findnthelement(head,n);
}
