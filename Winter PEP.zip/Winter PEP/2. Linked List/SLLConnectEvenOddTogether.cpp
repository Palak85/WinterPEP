#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        next = nullptr;
    }
};

Node* insertTail(Node* head, int ele) {
    if (head == nullptr)
        return new Node(ele);

    Node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = new Node(ele);
    return head;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

Node* evenoddtogether(Node* head) {
    if (head == nullptr)
        return nullptr;

    Node* curr = head;

    Node* evenSt = nullptr;
    Node* evenEnd = nullptr;
    Node* oddSt = nullptr;
    Node* oddEnd = nullptr;

    while (curr != nullptr) {
        Node* nextNode = curr->next;
        curr->next = nullptr;

        if (curr->data % 2 == 0) {
            if (evenSt == nullptr) {
                evenSt = evenEnd = curr;
            } else {
                evenEnd->next = curr;
                evenEnd = curr;
            }
        } else {
            if (oddSt == nullptr) {
                oddSt = oddEnd = curr;
            } else {
                oddEnd->next = curr;
                oddEnd = curr;
            }
        }
        curr = nextNode;
    }

    if (evenSt == nullptr)
        return oddSt;

    evenEnd->next = oddSt;
    return evenSt;
}

int main() {
    Node* head = nullptr;

    head = insertTail(head, 1);
    head = insertTail(head, 2);
    head = insertTail(head, 3);
    head = insertTail(head, 4);
    head = insertTail(head, 5);
    head = insertTail(head, 6);
    head = insertTail(head, 7);

    printList(head);

    head = evenoddtogether(head);

    printList(head);

    return 0;
}
