// //In this code i divided linked list in k number  of part and it should be equal and
// //if extra node remain then add in first patr of second part but not in last node
// #include <iostream>
// using namespace std;

// struct Node {
//     int data;
//     Node* next;

//     Node(int x) {
//         data = x;
//         next = nullptr;
//     }
// };

// void insertAtEnd(Node*& head, int x) {
//     Node* newNode = new Node(x);

//     if (head == nullptr) {
//         head = newNode;
//         return;
//     }

//     Node* temp = head;
//     while (temp->next != nullptr)
//         temp = temp->next;

//     temp->next = newNode;
// }

// void splitIntoKParts(Node* head, int k, Node* parts[]) {
//     int n = 0;
//     Node* temp = head;
//     while (temp != nullptr) {
//         n++;
//         temp = temp->next;
//     }

//     int baseSize = n / k;
//     int extra = n % k;

//     Node* cur = head;

//     for (int i = 0; i < k; i++) {
//         parts[i] = cur;

//         int partSize;
//         if (extra > 0) {
//             partSize = baseSize + 1;
//             extra--;
//         } else {
//             partSize = baseSize;
//         }

//         int j = 1;
//         while (j < partSize && cur != nullptr) {
//             cur = cur->next;
//             j++;
//         }

//         if (cur != nullptr) {
//             Node* nextPart = cur->next;
//             cur->next = nullptr;
//             cur = nextPart;
//         }
//     }
// }

// void display(Node* head) {
//     while (head != nullptr) {
//         cout << head->data << " ";
//         head = head->next;
//     }
//     cout << endl;
// }

// int main() {
//     Node* head = nullptr;

//     for (int i = 1; i <= 7; i++)
//         insertAtEnd(head, i);

//     int k = 3;
//     Node* parts[3];

//     splitIntoKParts(head, k, parts);

//     for (int i = 0; i < k; i++) {
//         cout << "Part " << i + 1 << ": ";
//         display(parts[i]);
//     }

//     return 0;
// }



// What this code does

// Create linked list

// Split into k parts

// Reverse each part

// Print each reversed part

// Connect all reversed parts

// Sort the final connected list

// Print the sorted list

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertAtEnd(Node*& head, int x) {
    Node* newNode = new Node(x);

    if (head == nullptr) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != nullptr)
        temp = temp->next;

    temp->next = newNode;
}

void splitIntoKParts(Node* head, int k, Node* parts[]) {
    int n = 0;
    Node* temp = head;
    while (temp != nullptr) {
        n++;
        temp = temp->next;
    }

    int baseSize = n / k;
    int extra = n % k;

    Node* cur = head;

    for (int i = 0; i < k; i++) {
        parts[i] = cur;

        int partSize = baseSize + (extra > 0 ? 1 : 0);
        if (extra > 0) extra--;

        for (int j = 1; j < partSize && cur != nullptr; j++)
            cur = cur->next;

        if (cur != nullptr) {
            Node* nextPart = cur->next;
            cur->next = nullptr;
            cur = nextPart;
        }
    }
}

Node* reverseList(Node* head) {
    Node* prev = nullptr;
    Node* curr = head;
    Node* next = nullptr;

    while (curr != nullptr) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

void display(Node* head) {
    while (head != nullptr) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

/* -------- MERGE SORT FUNCTIONS -------- */

Node* getMiddle(Node* head) {
    Node* slow = head;
    Node* fast = head->next;

    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

Node* merge(Node* a, Node* b) {
    if (a == nullptr) return b;
    if (b == nullptr) return a;

    if (a->data <= b->data) {
        a->next = merge(a->next, b);
        return a;
    } else {
        b->next = merge(a, b->next);
        return b;
    }
}

Node* mergeSort(Node* head) {
    if (head == nullptr || head->next == nullptr)
        return head;

    Node* mid = getMiddle(head);
    Node* second = mid->next;
    mid->next = nullptr;

    Node* left = mergeSort(head);
    Node* right = mergeSort(second);

    return merge(left, right);
}



int main() {
    Node* head = nullptr;

    for (int i = 1; i <= 10; i++)
        insertAtEnd(head, i);

    int k = 3;
    Node* parts[3];

    splitIntoKParts(head, k, parts);

    Node* newHead = nullptr;
    Node* tail = nullptr;

    for (int i = 0; i < k; i++) {
        parts[i] = reverseList(parts[i]);

        cout << "Reversed Part " << i + 1 << ": ";
        display(parts[i]);

        if (newHead == nullptr) {
            newHead = parts[i];
            tail = newHead;
        } else {
            tail->next = parts[i];
        }

        while (tail->next != nullptr)
            tail = tail->next;
    }

    cout << "Final Connected List: ";
    display(newHead);

    newHead = mergeSort(newHead);

    cout << "Sorted Final List: ";
    display(newHead);

    return 0;
}

