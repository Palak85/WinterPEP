#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* createList() {
    Node* head = NULL;
    Node* tail = NULL;

    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        int val;
        cin >> val;

        Node* newNode = new Node();
        newNode->data = val;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    return head;
}

void printList(Node* head) {
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
}

int main() {
    Node* head = createList();
    printList(head);
}
