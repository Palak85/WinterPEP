#include<iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = NULL;
    }
};

void insertEnd(Node* &head, Node* &tail, int x) {
    Node* newNode = new Node(x);
    if (head == NULL) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        tail = newNode;
    }
}

Node* rotateLeft(Node* head, int k) {
    if (head == NULL || k == 0)
        return head;

    Node* temp = head;
    while (temp->next != NULL) {   
        temp = temp->next;
    }
    
    temp->next = head;  

    for (int i = 1; i < k; i++) {
        head=head->next;
    }
    Node* newHead = head->next;
    head->next = NULL;  
    return newHead;
}


void display(Node* head) {
    while (head != NULL) {
        cout << head->data << "->";
        head = head->next;
    }
    cout << "NULL\n";
}

int main() {
    Node* head = NULL;
    Node* tail = NULL;

    insertEnd(head, tail, 10);
    insertEnd(head, tail, 20);
    insertEnd(head, tail, 30);
    insertEnd(head, tail, 40);
    insertEnd(head, tail, 50);

    int k;
    cin >> k;

    head = rotateLeft(head, k);
    display(head);
}
