#include<bits/stdc++.h>
using namespace std;
class Node{
    public:
    int data;
    Node*next;
    Node(int x){
        data=x;
        next=nullptr;
    }
};
void swap(Node *&Head){
    Node *temp=Head;
    while(temp!=nullptr&& temp->next!=nullptr){
        int x=temp->data;
        temp->data=temp->next->data;
        temp->next->data=x;
        temp=temp->next->next;
    }
}
void display(Node *Head){
    while(Head!=nullptr){
        cout<<Head->data<<"-->";
        Head= Head->next;
    }
    cout<<"NULL";
}

int main(){
    int n;
    cout<<"Enter the size of ll ";
    cin>>n;

    Node *Head=nullptr;
    Node*temp=nullptr;

    for(int i=0;i<n;i++){
        int val;
        cout<<"Enter the element ";
        cin>>val;
        Node *newnode =new Node(val);
        if(Head==nullptr){
            Head=newnode;
            temp=Head;
        }
        else{
            temp->next=newnode;
            temp=newnode;
        }
    }
    swap(Head);
    display(Head);
}