//HERE I AM MERGING TWO SORTED LINKED LISTAND I TRY TO GET NEW SORTED LINKED LIST
#include <iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
    
    Node(int x){
        data=x;
        next=nullptr;
    
    }
};

int Count(Node* head){
    int c=0;
    Node* temp =head;
    while(temp!=NULL){
        temp=temp->next;
        c++;
    }
    return c;
}

void insertrear(Node* &head,int data)
{
    Node* new_node=new Node(data);
    if(head==nullptr)
    {
        head=new_node;
    }
    else
    {
        Node* temp=head;
        while(temp->next!=nullptr)
        {
            temp=temp->next;
        }
        temp->next=new_node;
        
}
}


void display1(Node* &head)
{
    Node* tem=head;
    while(tem!=nullptr)
    {   
        cout<<tem->data<<" ";
        tem=tem->next;
    }
    cout<<endl;
}

bool Identical(Node* &head1, Node* &head2)
{
    Node* a=head1;
    Node* b=head2;

    int c1=Count(head1);
    int c2=Count(head2);
    
    if(c1!=c2){
        return false;
    }

    while (head1 != nullptr && head2 != nullptr) {
        if (head1->data != head2->data)
            return false;
        head1 = head1->next;
        head2 = head2->next;
    }
    return true;
}


int main() { 
    Node* head1=nullptr;
    Node* head2=nullptr;    
    
    
    insertrear(head1,1);
    insertrear(head1,2);
    insertrear(head1,3);
    
    insertrear(head2,1);
    insertrear(head2,2);
    insertrear(head2,3);


    display1(head1);
    display1(head2);
    
    if (Identical(head1, head2))
        cout << "Linked lists are IDENTICAL\n";
    else
        cout << "Linked lists are NOT identical\n";
    return 0;
}