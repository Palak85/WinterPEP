#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;

    Node(int x) {
        data = x;
        next = nullptr;
    }
};

void insertatrear(Node* &head, Node* &tail, int data) {
    Node* new_node = new Node(data);

    if (head == nullptr) {
        head = new_node;
        tail = new_node;
        tail->next = head;
    } else {
        tail->next = new_node;
        tail = new_node;
        tail->next = head;
    }
}

void merge(Node* &head1,Node* tail1,Node* &head2,Node* tail2){
    if(head1 ==nullptr && head2==nullptr){
    cout<<"both the linked list is null";
    }

    tail1->next=nullptr;
    tail2->next=nullptr;

    tail1->next=head2;
    tail2->next=head1;

   
    return;
}

void display(Node* head) {
    if (head == nullptr)
        return;

    Node* temp = head;
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);

    cout << endl;
}

int main() {
    Node* head1 = nullptr;
    Node* tail1 = nullptr;

    Node* head2 = nullptr;
    Node* tail2 = nullptr;

    insertatrear(head1, tail1, 10);
    insertatrear(head1, tail1, 20);
    insertatrear(head1, tail1, 30);
    insertatrear(head1, tail1, 40);
    insertatrear(head1, tail1, 50);

    insertatrear(head2, tail2, 60);
    insertatrear(head2, tail2, 70);
    insertatrear(head2, tail2, 80);
    insertatrear(head2, tail2, 90);
    insertatrear(head2, tail2, 100);
    
    display(head1);
    display(head2);

    merge(head1,tail1,head2,tail2);

    display(head1);
}
